#pragma once
#include "global.h"

using namespace std;

struct TrieNode {
    TrieNode *state[ALPHABET];
    TrieNode *pi;
    vector<pair<pair<int, int>, int>> *sub;
    int dep;
    TrieNode()
    {
      fill_n(state, ALPHABET, nullptr);
      sub = nullptr;
    }
    ~TrieNode()
    {
      FOR(i, 0,ALPHABET)
        delete state[i];
    }
    static void traverse(TrieNode *p, function<void(vector<pair<pair<int, int>,int>>&)> fn);
};
