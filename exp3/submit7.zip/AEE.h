#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <err.h>
#include <fcntl.h>
#include <map>
#include <queue>
#include <string>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <unordered_map>
#include <vector>
#include "global.h"
#include "TrieNode.h"


const int SUCCESS = 0;
const int FAILURE = 1;

template <typename _IDType, typename _PosType, typename _LenType, typename _SimType>
struct ExtractResult
{
	_IDType id;
	_PosType pos;
	_LenType len;
	_SimType sim;
};

typedef ExtractResult<unsigned, unsigned, unsigned, unsigned> EDExtractResult;
typedef ExtractResult<unsigned, unsigned, unsigned, double> JaccardExtractResult;

class AEE {
public:
  AEE() : tup(-1, nullptr, 0) {}
  ~AEE();

  tuple<int, char *, size_t> read_file(const char *filename);
  int createIndex(const char *filename);
  int aeeJaccard(const char *doc, double threshold, std::vector<JaccardExtractResult> &result);
  int aeeED(const char *doc, unsigned threshold, std::vector<EDExtractResult> &result);
  EDExtractResult packED(unsigned, unsigned, unsigned, unsigned);

  int q;

  vector<string> entity;
  vector<string> re_entity;

  //文件描述符 内存映射 文件大小
  tuple<int, char *, size_t> tup;

  int last_seg = -1;
  TrieNode *trie_root = nullptr;
};
