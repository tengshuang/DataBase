#include "TrieNode.h"

void TrieNode::traverse(TrieNode *p, function<void(vector<pair<pair<int, int>,int>>&)> fn)
{
  if (! p) return;
  if (p->sub)
    fn(*p->sub);
  FOR(i, 0,ALPHABET)
    if (p->state[i] && p->state[i]->dep == p->dep+1)
      traverse(p->state[i], fn);
}
