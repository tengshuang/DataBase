#pragma once
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

#define N  3000
#define ALPHABET 40
#define Q0 5

#define FOR(i, a, b) for (remove_cv<decltype(b)>::type i = (a); i < (b); i++)

