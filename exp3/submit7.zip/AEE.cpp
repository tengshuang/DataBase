#include "AEE.h"
using namespace std;
tuple<int, char *, size_t> AEE::read_file(const char *filename)
{
  int fd = open(filename, O_RDONLY);
  if (fd < 0)
    errx(1, "failed to open %s: %s", filename, strerror(errno));
  struct stat s;
  int status = fstat(fd, &s);
  if (status < 0)
    errx(1, "failed to stat %s: %s", filename, strerror(errno));
  char *mapped = (char *)mmap(0, s.st_size, PROT_READ, MAP_PRIVATE | MAP_POPULATE, fd, 0);
  return tuple<int, char *, size_t>(fd, mapped, s.st_size);
}
EDExtractResult AEE::packED(unsigned a, unsigned b, unsigned c, unsigned d){
	EDExtractResult res;
	res.id = a;
	res.len = c;
	res.pos = b;
	res.sim = d;
	return res;
}

AEE::~AEE(){
	if (get<0>(tup) != -1) {
	    munmap(get<1>(tup), get<2>(tup));
	    close(get<0>(tup));
	    get<0>(tup) = 0;
	    get<1>(tup) = nullptr;
	    get<2>(tup) = 0;
	  }
}
template <typename T>
void print(vector<T> e){
	for(int i=0; i<e.size(); i++)
	{
		cout <<"======" << "num: " << i + 1 << "======"<< endl;
	    cout<<e[i] << endl;
	}
}
int AEE::createIndex(const char *filename)
{
  this-> q = Q0;

  entity.clear();

  if (get<0>(tup) != -1) {
      munmap(get<1>(tup), get<2>(tup));
      close(get<0>(tup));
      get<0>(tup) = 0;
      get<1>(tup) = nullptr;
      get<2>(tup) = 0;
    }

  tup = read_file(filename);
  char *mapped = get<1>(tup);
  //cout << "---------------------------------"<< endl;
  //cout << mapped;
  //cout << "---------------------------------"<< endl;
  int file_size = int(get<2>(tup)), eid = 0;
  for (int i = 0, j = 0; j < file_size; i = j, eid++) {
    for (; j < file_size && mapped[j] != '\n'; j++);
    //cout << "======= eid:" << eid << "==========" << endl;
    entity.emplace_back(mapped+i, j-i);
    re_entity.emplace_back(mapped+i, j-i);
    reverse((re_entity.back()).begin(), (re_entity.back()).end());
    if (j < file_size && mapped[j] == '\n')
      j++;
  }
 // print(e);
 // print(re);
  return SUCCESS;
}
bool Cmp_f(const pair<pair<int, int>,int> &b, const pair<pair<int, int>,int> &c)
{
	return b.first.second < c.first.second;
}
bool Cmp_ed(const EDExtractResult &a, const EDExtractResult &b) {
  		  if (a.id != b.id) return a.id < b.id;
  		  if (a.pos != b.pos) return a.pos < b.pos;
  		  return a.len < b.len;
}
bool Cmp_eq(const EDExtractResult &a, const EDExtractResult &b) {
  		  return a.id == b.id && a.pos == b.pos && a.len == b.len;
         	 }
int AEE::aeeED(const char *doc, unsigned threshold, vector<EDExtractResult> &result)
{
	int seg = threshold;
	if (seg != last_seg)
	{
		int segNum = 0;//记录seg的编号
		if (last_seg != -1) delete trie_root;
		trie_root = new TrieNode;
		trie_root -> dep = 0;
		FOR(i, 0,entity.size())//遍历所有行
		{
			int n = entity[i].size();
			//划分为tau+1个片段存入trie
			int segLen = n/(seg+1);
			int leftLen = n % (seg+1);

			int start = 0;
			FOR(j, 0,seg + 1)
			{
				int end = start + segLen + (j < leftLen);
				//cout << "pos: " << ~start << endl;
				//cout << "pos2: " << pos2<< endl;
				TrieNode *nextNode = trie_root;
				//构造tire树，每个node对应26位字母表
				FOR(k, start, end)
				{
					uint8_t c = entity[i][k];
					if (c == ' ') c = 36;
					else if (unsigned(c-'0') < 10) c = c-'0'+26;
					else c -= 'a';
					TrieNode *&q = nextNode->state[c];
					if (! q) {
						q = new TrieNode;
						q -> dep = k - start + 1;
					}
					nextNode = q;
				}
				if (! nextNode->sub) nextNode->sub = new vector<pair<pair<int, int>, int>>;
				nextNode->sub->emplace_back(make_pair(i, end), segNum);
				nextNode->sub->emplace_back(make_pair(i, ~start), segNum++);//取负和pos2区别
				start = end;
			}
		}

    // AC自动机
		queue<TrieNode*> ACque;
		FOR(i, 0,ALPHABET)
		{
			if (trie_root->state[i]){
				trie_root->state[i]->pi = trie_root;
				ACque.push(trie_root->state[i]);
			}
			else
				trie_root->state[i] = trie_root;
		}
		while (!ACque.empty())
		{
			TrieNode *p = ACque.front();
			ACque.pop();
			FOR(i, 0,ALPHABET) //遍历26个字母
			{
				if (p->state[i])
				{
					p->state[i]->pi = p->pi->state[i];
					ACque.push(p->state[i]);
				}
				else
					p->state[i] = p->pi->state[i];
			}
		}
		//此处使用lambda特性，捕获父作用域中的seg片段
		trie_root->traverse(trie_root, [&](vector<pair<pair<int, int>,int>> &a) {
			if (a.empty()) return;
                  // pre (<0) | post (>=0)
			sort(a.begin(),a.end(), Cmp_f);
                  // sort pre
			sort(a.begin(), a.begin()+a.size()/2, [&](const pair<pair<int, int>,int> &b, const pair<pair<int, int>,int> &c) {
            	return strcmp(&re_entity[b.first.first][re_entity[b.first.first].size()-~b.first.second], &re_entity[c.first.first][re_entity[c.first.first].size()-~c.first.second]) < 0;
            });
                  // sort post
            sort(a.begin()+a.size()/2, a.end(), [&](const pair<pair<int, int>,int> &b, const pair<pair<int, int>,int> &c) {
            	return strcmp(&entity[b.first.first][b.first.second], &entity[c.first.first][c.first.second]) < 0;
            });
		});
		last_seg = seg;
  }
  result.clear();

  static int dis[N][N];

  int m = strlen(doc);
  char *rdoc = strdup(doc);
  reverse(rdoc, rdoc+m);

  TrieNode *temp = trie_root;
  TrieNode *nextNode;
  for (int i, ii = 0, j = 0; j < m; )
  {
	  uint8_t c = doc[j++];

	  if (c == ' ') c = 36;
	  else if (unsigned(c-'0') < 10) c = c-'0'+26;
	  else c -= 'a';

	  ii += temp->dep+1-temp->state[c]->dep;
	  temp = temp->state[c];

	  for (i = ii, nextNode = temp; nextNode; i += nextNode->pi ? nextNode->dep-nextNode->pi->dep : 0, nextNode = nextNode->pi)
		  if (nextNode->sub)
		  {
			  int eeid = -1;
			  int nexPos = 0;
			  const char *aa = NULL;
			  //delete repeat item
			  unordered_map<int, vector<vector<int>>> ans;
			  FOR(l, 0, seg + 1) dis[0][l] = l;
			  FOR(eidx, 0,nextNode->sub->size())
			  {
				  bool left = eidx < nextNode->sub->size()/2;
				  int eid = nextNode->sub->at(eidx).first.first;
				  int pos = nextNode->sub->at(eidx).first.second;
				  int tag = nextNode->sub->at(eidx).second;
				  int Cur;
				  int lcp = 0;
				  const char *a, *b;
				  //左侧ed，右侧复用
				  if (left) {
					  Cur = ~pos;
					  a = &re_entity[eid][re_entity[eid].size()-Cur];
					  b = rdoc+m-i;
				  } else {
					  a = &entity[eid][pos];
					  b = doc+j;
					  Cur = entity[eid].size()-pos;
				  }
				  if (eidx == nextNode->sub->size()/2) eeid = -1;
				  if (eeid != -1)//非中心位置
				  {
					  int maxl = min(Cur, nexPos);//取最小
					  while (lcp < maxl && a[lcp] == aa[lcp]) lcp++;
				  }
				  eeid = eid;
				  nexPos = 0;
				  aa = a;
				  for (int k = lcp+1; k <= Cur; k++)
				  {
					  bool discard = true;
					  int l = max(k-seg, 0), h = min(k+seg, left ? i : m-j);
					  if (! l)
						  dis[k][l++] = k;
					  FOR(o, l, h+1)
					  {
						  dis[k][o] = a[k-1] == b[o-1] ? dis[k-1][o-1] : min(min(o-(k-1) > seg ? seg : dis[k-1][o], k-(o-1) > seg ? seg : dis[k][o-1]), dis[k-1][o-1]) + 1;
						  if (dis[k][o] <= seg)
							  discard = false;
					  }
					  nexPos = k;
					  if (discard) goto beyond;
				  }
				  {
					  int l = max(Cur-seg, 0), h = min(Cur+seg, left ? i : m-j);
					  vector<vector<int>> dul(seg+1);
					  if (left)
					  {
						  FOR(kk, l, h+1)
							if (dis[Cur][kk] <= seg && i-kk >= 0)
								dul[dis[Cur][kk]].push_back(i-kk);
						  ans[tag] = dul;
					  }
					  else
					  {
						  if (! ans.count(tag)) continue;
						  vector<vector<int>> &dulr = ans[tag];
						  FOR(kk, l, h+1)
						  if (dis[Cur][kk] <= seg && j+kk <= m)
							  dul[dis[Cur][kk]].push_back(j+kk);
						  FOR(k1, 0,seg+1)
						  	  FOR(k2,0, seg-k1+1)
						  	  	  for (auto u: dulr[k1])
						  	  		  for (auto v: dul[k2])
						  	  		  {
						  	  			  EDExtractResult res = packED(eid,u,v-u,k1+k2);
						  	  			  result.push_back(res);
						  	  		  }
					  }
				  }
				  beyond:;
			  }
		  }
  	  }
  	  sort(result.begin(), result.end(), Cmp_ed);
  	  result.erase(unique(result.begin(), result.end(), Cmp_eq), result.end());
  	  //sort(result.begin(), result.end(), Cmp_ed);
  	  free(rdoc);
  	  return 0;
}

int AEE::aeeJaccard(const char *doc, double threshold, vector<JaccardExtractResult> &result)
{
  return 0;
}
